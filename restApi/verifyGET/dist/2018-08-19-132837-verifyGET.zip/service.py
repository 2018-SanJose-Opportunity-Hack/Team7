""" GET for roles
"""
import boto3
import subprocess
from subprocess import check_output
import json


def find_similarity(text1="Amazing Book", text2="This Book is very good!"):
    curl_cmd = "curl -X POST \
                  https://twinword-text-similarity-v1.p.mashape.com/similarity/ \
                  -H 'Cache-Control: no-cache' \
                  -H 'Content-Type: application/x-www-form-urlencoded' \
                  -H 'Postman-Token: 1b00da61-baff-4326-8de1-967249a7aa84' \
                  -H 'X-Mashape-Key: KaJd5e6lWAmshWITUI7kQC7xYVqnp1y4TYrjsnzCO3uKCAcgZg' \
                  -d 'text1={}&text2={}'".format(text1, text2)

    return json.loads(check_output(["curl_cmd"]))

def handler(event, context):
    client = boto3.client("dynamodb")
    key = {"id": {"S": event.get("id")}}
    items = client.scan(TableName="complaints")
    response = []
    for item in items.get("Items"):
        return find_similarity(item.get("title").get("S"),event.get("title"))
        if find_similarity(item.get("title").get("S"),event.get("title")) > 0.75 and item.get("park").get("S") == event.get("park") and item.get("category").get("S")==event.get("category"):
            response.append(item)
    return response



""" body mapping templates: 
input:
{"id":"$input.params('id')"}
output:
#set($inputRoot = $input.path('$'))
{
    "id": "$inputRoot.id",
    "name": "$inputRoot.name"
}
"""