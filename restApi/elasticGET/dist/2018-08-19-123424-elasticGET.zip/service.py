""" POST for role.
"""
import boto3

def get_complaint(id,client):
    key = {"id": {"S": id}}
    complaint = {}
    try:
        item = client.get_item(TableName="complaints",Key=key)
        complaint ["id"] = item.get("Item").get("id").get("S")
        complaint ["title"] =  item.get("Item").get("title").get("S")
        complaint ["image_url"] = item.get("Item").get("image_url").get("S")
        complaint ["description"] = item.get("Item").get("description").get("S")
        complaint ["last_updated"] = item.get("Item").get("last_updated").get("S")
        complaint ["time"] = item.get("Item").get("time").get("S")
        complaint["callback"] = item.get("Item").get("callback").get("S")
    except Exception, exception:
        return exception
    
    return complaint

def handler(event, context):
    client = boto3.client("dynamodb")
    complaints = []
    try:
        items = client.scan(TableName="complaints")
        for complaint in items.get("Items"):
            complaints.append(get_complaint(complaint.get("id").get("S"),client))

    except Exception, exception:
        return exception
    return complaints