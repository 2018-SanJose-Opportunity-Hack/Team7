""" POST for role.
"""
import boto3

def get_community(id, boto_client):
    key = {"id": {"S": id}}
    item = boto_client.get_item(TableName="communities",Key=key)
    community = {}
    community["id"] = id
    community["name"] = item.get("Item").get("name").get("S")
    return community   


def get_complaint(id,client):
    key = {"id": {"S": id}}
    complaint = {}
    try:
        item = client.get_item(TableName="complaints",Key=key)
        complaint ["id"] = item.get("Item").get("id").get("S")
        complaint ["title"] =  item.get("Item").get("title").get("S")
        complaint ["image_url"] = item.get("Item").get("image_url").get("S")
        complaint ["description"] = item.get("Item").get("description").get("S")
        complaint ["last_updated"] = item.get("Item").get("last_updated").get("S")
        complaint ["time"] = item.get("Item").get("time").get("S")
        complaint["callback"] = item.get("Item").get("callback").get("S")
        key = {"id": {"S": item.get("Item").get("park").get("S")}}
        
        park_item = client.get_item(TableName="parks",Key=key)
        
        park = {}
        park ["id"] = park_item.get("Item").get("id").get("S")
        park ["name"] =  park_item.get("Item").get("name").get("S")
        park ["address"] = park_item.get("Item").get("address").get("S")
        park ["description"] = park_item.get("Item").get("description").get("S")
        park ["image_url"] = park_item.get("Item").get("image_url").get("S")
        park ["location"] = {}
        park ["location"]["lat"] = park_item.get("Item").get("location").get("M").get("lat").get("N")
        park ["location"]["long"] = park_item.get("Item").get("location").get("M").get("long").get("N")
        park ["community"] = get_community(park_item.get("Item").get("community").get("S"), client)
        complaint ["park"] = park

    except Exception, exception:
        return exception
    return complaint
    
    
    

def handler(event, context):
    client = boto3.client("dynamodb")
    complaints = []
    try:
        items = client.scan(TableName="complaints")
        for complaint in items.get("Items"):
            complaints.append(get_complaint(complaint.get("id").get("S"),client))

    except Exception, exception:
        return exception
    return complaints