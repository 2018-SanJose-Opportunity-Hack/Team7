""" POST for role.
"""
import boto3



def handler(event, context):
    client = boto3.client("dynamodb")
    try:
        items = client.scan(TableName="complaints")
    except Exception, exception:
        return exception
    return items