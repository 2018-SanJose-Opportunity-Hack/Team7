""" POST for role.
"""
import uuid
import boto3

def handler(event, context):
    client = boto3.client("dynamodb")
    item = {
            "name": {
                "S": event.get("name")
            },
            "image_url": {
                "S": event.get("image_url")
            },
            "phone": {
                "S": event.get("phone")
            },
            "address": {
                "S": event.get("address")
            },
            "email": {
                "S": event.get("email")
            },
            "phone_token": {
                "S": event.get("phone_token")
            },
            "time": {
                "S": event.get("time")
            },
            "role": {
                "S": event.get("role")
            },
            "location": {
                "M": {
                    "lat":{
                        "N": event.get("location").get("lat")
                        }
                    "long":{
                        "N": event.get("location").get("long")
                        }
                }
            },
            "id": {
                "S": str(uuid.uuid4())
            }
        }
    try:
        client.put_item(TableName="users", Item=item)
    except Exception, exception:
        return exception
    event["id"]=item.get("id").get("S")
    return event