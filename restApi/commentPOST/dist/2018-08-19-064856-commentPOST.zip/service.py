""" POST for role.
"""
import uuid
import boto3
import time

def handler(event, context):
    client = boto3.client("dynamodb")
    item = {
            "time": {
                "S": str(time.time())
            },
            "description": {
                "S": event.get("description")
            },
            "user": {
                "S": event.get("user")
            },
            "complaint": {
                "S": event.get("complaint")
            },
            "id": {
                "S": str(uuid.uuid4())
            }
        }
    try:
        client.put_item(TableName="comments", Item={"id":item})
        complaint = client.get_item(TableName="complaints",Key=item.get("complaint"))
        complaint["comments"].append(item.get("id"))
        client.update_item(TableName="complaints", Key={"id":item.get("complaint")}, UpdateExpression="set complaints=:c", ExpressionAttributeValues={":c":complaint.get("comments")})
    except Exception, exception:
        return exception
    event["id"]=item.get("id").get("S")
    return event